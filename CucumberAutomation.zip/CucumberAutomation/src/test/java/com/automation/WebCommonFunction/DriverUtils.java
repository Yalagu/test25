package com.automation.WebCommonFunction;

import com.automation.MobileWebMainFunction.BaseClass;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;

import java.io.*;
import java.util.*;

public class DriverUtils extends BaseClass {
	public static long DEFAULT_WAIT = 20;
	static String currentPath = System.getProperty("user.dir");
	public static File resourcesDirectory = new File(currentPath + "\\src\\test\\resources\\downloads");
	static Properties prop = new Properties();
	private static Integer timeout = 50;
	public static RandomDataGenerator RandomDataGenerator = new RandomDataGenerator();
	public static int randomNumber;
	public static String randomString;
	public static String randomAlphaNumericValue;
	public static String randomSpecialString;

	private static final Logger logger = LoggerFactory.getLogger(DriverUtils.class);

	static {
		randomNumber = RandomDataGenerator.getRandomNumber(10001, 10000001);
		randomAlphaNumericValue = RandomStringUtils.randomAlphanumeric(20).toUpperCase(Locale.ROOT);
		System.out.println("The random number generated for this run is:" + randomNumber);
		randomString = RandomDataGenerator.getRandomString(7);
		System.out.println("The random string generated for this run is:" + randomString);
		randomSpecialString = RandomDataGenerator.generateSpecialCharacterString(10);
		System.out.println("The random special char string generated for this run is:" + randomSpecialString);
	}
	public boolean isElementDisplayedID(String id) throws InterruptedException {
		boolean res=false;
		for(int i=0;i<=10;i++) {
			try {
				res = driver.findElement(By.id(id)).isDisplayed();
				if(res){
					break;
				}
			} catch (Exception e) {
				System.out.println("xpath not found"+e);
			}
				Thread.sleep(5000);
		}
		return res;
	}
	public boolean isElementDisplayedXpath(String xpath) throws InterruptedException {
		boolean res=false;
		for(int i=0;i<=10;i++) {
			try {
				res = driver.findElement(By.xpath(xpath)).isDisplayed();
				if(res){
					break;
				}
			} catch (Exception e) {
				System.out.println("xpath not found"+e);
			}
			Thread.sleep(5000);
		}
		return res;
	}
	public boolean isElementDisplayed(WebElement element) throws InterruptedException {
		boolean res=false;
		for(int i=0;i<=10;i++) {
			try {
				res =element.isDisplayed();
				if(res){
					break;
				}
			} catch (Exception e) {
				System.out.println("xpath not found:"+e);
			}
			Thread.sleep(1000);
		}
		return res;
	}
	public void click(WebElement element) throws InterruptedException {
		boolean res=false;
		for(int i=0;i<=10;i++) {
			try {
				element.click();
				res=true;
				break;
			} catch (Exception e) {
				System.out.println("xpath not found"+e);
			}
			Thread.sleep(1000);
		}
		Assert.assertEquals(true,res,"failed to click");
	}

	public  void scrollIntoView(WebElement element){
			driver.executeScript("arguments[0].scrollIntoView(true);", element);
	}

}