package com.automation.stepdefs;


import com.automation.MobileWebMainFunction.BaseClass;
import com.automation.MobileWebMainFunction.MobileWebFunction;
import com.automation.WebCommonFunction.DriverUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

import java.net.MalformedURLException;

public class WebClassStepDef extends  DriverUtils{
    MobileWebFunction mobileWebFunction=new MobileWebFunction();

    @Given("^I launch mobile '(.*?)' browser in android device$")
    public void launchBrowser(String browserName) throws MalformedURLException {
        new BaseClass().launchMobileBrowser(browserName,CommonDef.currentScenario);
    }

    @Given("^I launch BS mobile '(.*?)' browser in android device$")
    public void launchBSBrowser(String browserName) throws MalformedURLException {
        new BaseClass().launchMobileInBsBrowser(browserName,CommonDef.currentScenario);
    }

    @When("^I launch url in browser$")
    public void launchURL() {
        BaseClass.driver.get("https://www.premierinn.com/gb/en/home.html");
    }

    @When("^I accept cookies$")
    public void acceptCookies() throws InterruptedException {
        mobileWebFunction.setAcceptAllCookies();
    }

    @And("^I click on sign up btn$")
    public void clickOnSignUpBtnDef() throws InterruptedException {
        mobileWebFunction.clickOnSignOutBtn();

    }

    @And("^I enter first name as '(.*?)'$")
    public void enterFirstName(String fName) throws InterruptedException {
        mobileWebFunction.enterFirstName(fName);
    }

    @And("^I enter last name as '(.*?)'$")
    public void enterLastName(String lName) throws InterruptedException {
        mobileWebFunction.enterLastName(lName);
    }

    @And("^I enter email as '(.*?)'$")
    public void enterEmail(String email) throws InterruptedException {
        mobileWebFunction.enterEmail(email);
    }

    @And("^I click on sign up submit btn$")
    public void clickOnSignUpSubmitBtn() throws InterruptedException {
        mobileWebFunction.clickOnSignUpConfirmBtn();
    }

    @And("^I verify sucess message$")
    public void verifySucessMsg() throws InterruptedException {
        mobileWebFunction.verifySucesssMsg();
    }

    @And("^I verify card details message$")
    public void verifyCardDetailsMsg() throws InterruptedException {
        mobileWebFunction.verifyPaymentDeatilsHeaderMsg();
    }


    @And("^I click on Hamburger menu btn$")
    public void clickHambergerMenuBtnDef() throws Exception {
        mobileWebFunction.clickOnHambergurerMenu();
    }

    @And("^I click on login options in menu list$")
    public void clickLoginOptionInMenuListDef() throws Exception {
        mobileWebFunction.clickOnLoginBtn();
    }

    @And("^I enter login email name as '(.*?)'$")
    public void enterLastNameDef(String email) throws Exception {
        mobileWebFunction.enterLoginEmailInputValue(email);
    }

    @And("^I enter login password name as '(.*?)'$")
    public void enterPasswordDef(String password) throws Exception {
        mobileWebFunction.enterLoginPwdInputValue(password);
    }

    @And("^I click on login submit btn$")
    public void loginInSumbitBtnDef() throws Exception {
        mobileWebFunction.clickOnLoginSubmitBtn();
    }

    @And("^I wait till '(.*?)' show in menu list$")
    public void loginInSumbitBtnDef(String name) throws Exception {
        mobileWebFunction.waitTillUserNameUntilShow(name);
    }

    @And("^I enter search hotel name as '(.*?)'$")
    public void searchHotelNameDef(String name) throws Exception {
        mobileWebFunction.enterLocationName(name);
    }

    @And("^I select default date$")
    public void selectDeafultDateDef() throws Exception {
        mobileWebFunction.enterDateDefaultDate();
    }

    @And("^I click search hotel button$")
    public void searchHotelBtnDef() throws Exception {
        mobileWebFunction.enterHotelSearchBtn();
    }


    @And("^I select hotel name based on index '(.*?)'$")
    public void searchBasedOnHotelIndexDef(String index) throws Exception {
        mobileWebFunction.selectHotelNameBasedOnIndex(index);
    }

    @And("^I click on book now btn$")
    public void clickOnBookNowBtnDef() throws Exception {
        mobileWebFunction.clickOnBookNowBtn();
    }

    @And("^I select adult count as '(.*?)'$")
    public void clickOnBookNowBtnDef(String count) throws Exception {
        mobileWebFunction.clickAddPlusBtn(count);
    }


    @And("^I click on continue btn$")
    public void clickContinueBtnDef() throws Exception {
        mobileWebFunction.clickOnContinueBtn();
    }

    @And("^I select reason as '(.*?)'$")
    public void selectReasonCheckBoxDef(String type) throws Exception {
        mobileWebFunction.reasonForStay(type);
    }

    @And("^I select  terms and Condition check box$")
    public void selectTermsCheckBoxDef(String type) throws Exception {
        mobileWebFunction.clickOnTermsAndCondition();
    }

    @And("^I click on continue to next btn$")
    public void clickContiuneToNextDef() throws Exception {
        mobileWebFunction.clickContinueToNext();
    }




}
