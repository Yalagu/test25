package com.automation.MobileWebMainFunction;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.cucumber.java.Scenario;
import org.openqa.selenium.MutableCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.HashMap;

public class BaseClass {

    public static AppiumDriver driver = null;

    HashMap<String, Object> browserstackOptions = new HashMap<String, Object>();

    public static String username = "yalagureshmk_HEiex4";
    public static String accesskey = "Am1xvbdhb9zWWx85JTDU";
    public static final String URL = "https://" + username + ":" + accesskey + "@hub-cloud.browserstack.com/wd/hub";


    public void launchMobileInBsBrowser(String browserName, Scenario scenario) throws MalformedURLException {
        MutableCapabilities capabilities=new MutableCapabilities();
        browserstackOptions.put("browserName", browserName);
        browserstackOptions.put("deviceName", "Google Pixel 6 Pro");
        browserstackOptions.put("realMobile", "true");
        browserstackOptions.put("osVersion", "13");
        capabilities.setCapability("name", scenario.getName());
        capabilities.setCapability("bstack:options", browserstackOptions);
        driver = new AppiumDriver(new URL(URL), capabilities);
        driver.manage()
                .timeouts()
                .implicitlyWait(Duration.ofSeconds(60));
    }
        public void launchMobileBrowser(String browserName,Scenario scenario) throws MalformedURLException {
            UiAutomator2Options capabilities = new UiAutomator2Options()
                    .setPlatformName("Android")
                    .setDeviceName("emulator-5554").
                    setNewCommandTimeout(Duration.ofMinutes(5l))
                    .noReset().withBrowserName(browserName);
            capabilities.setCapability("connectHardwareKeyboard", false);

            // Open browser.
            driver =new AppiumDriver(new URL("http://localhost:4723/wd/hub"), capabilities);
            driver.manage()
                    .timeouts()
                    .implicitlyWait(Duration.ofSeconds(60));
        }
}
